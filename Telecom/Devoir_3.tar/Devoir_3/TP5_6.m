%2
%information binaire a transmettre
    Fe=24000;
    Te=1/Fe;
    Rb=6000;
    %longueur du message en bits
    nb_bits=10000;
    %generation de l'information binaire a transmettre
    bits=randi([0 1],1,nb_bits);
 %Modulateur/demodulateur1
    %nombre de symbole possibles pour le modulateur1 
    M=2;
    %debit symbole
    Rs=Rb/log2(M);
    %Duree symbole en nombre d'echantillons (Ts=NsTe)
    Ns=Fe/Rs;
    %reponse_impulsionnellle_globale 
    %modulateur1
    h1=ones(1,Ns);
    %Mapping binaire a? moyenne nulle : 0->-1, 1->1 
    Symboles=2*bits-1;
    %Surechantillionnage modulateur1
    suite_diracs=kron(Symboles,[1 , zeros(1,Ns-1)]);
    %filtrage
    X1=filter(h1,1, suite_diracs);
    %signal recu
    X1r=filter(h1,1,X1);
    %echantillonnage
    n0=Ns;
    X1e=X1r(n0:Ns:length(X1r));
    %decisions /demaping
    X1e(X1e>0)=1;
    X1e(X1e<0)=0;
    %taux d'erreur binnaire
    erreur=mean(abs(X1e - bits))
% 2.3 % bruit 
Px=mean(abs(X1).^2);
%2.3.1
figure;
for i=-1:3
    rapportEN=10^i;
    sigma=sqrt(Px*Ns/(2*log(M)*rapportEN));
    bruit=sigma*rand(1,length(X1));
    %signal bruit
    X1b=X1+bruit;
    %signal recu
    X1br=filter(h1,1,X1b);
    subplot(2,3,(i+2));
    %diagrame de l'oeil
    plot(reshape(X1br,Ns,length(X1br)/Ns));
    str=sprintf('%f',rapportEN);
    title("diagrame de l'oeil pour E/N ="+ str);
end
sgtitle('question 2.3.1: Diagrame de l oeil de la chaine de réference pour différentes valeurs de Eb/No');
% 2.3.2
%valeur de E/N
rapportEN=linspace(1,4,100)';
sigma=sqrt(Px*Ns./(2*log2(M).*rapportEN));
bruit=sigma*randn(1,length(X1));
X1t=repmat(X1,length(rapportEN),1);
%signal bruité
X1b=X1t+bruit;
%signal recu
X1br=zeros(size(X1b));
for i=1:size(X1b,1)
    X1br(i,:)=filter(h1,1,X1b(i,:));
end     
%echantillionnage
n0=Ns;
X1be=X1br(:,n0:Ns:length(X1br));
%decisions/demapping
X1be(X1be>0)=1;
X1be(X1be<0)=0;
% tracé du TEB
bitst=repmat(bits,length(rapportEN),1);
erreurb= mean(abs(X1be - bitst),2)';
figure;
semilogy(10*log(rapportEN),erreurb);
erreurth=qfunc(sqrt(2*rapportEN));
hold on;
semilogy(10*log(rapportEN),erreurth);
title('trace du TEB de la chaine de reference en fonction de Eb/No');
legend('TEB simulé','TEB théorique');
%% 3
Rb=6000;
Fe=24000;
%longueur du message en bits
nb_bits=10000;
%generation de l'information binaire a transmettre
bits=randi([0 1],1,nb_bits);
%modulateur 
M=2;
Rs=Rb/log2(M);
Ns=Fe/Rs;
h1=ones(1,Ns);
%Mapping binaire a? moyenne nulle : 0->-1, 1->1 
Symboles=2*bits-1;
%Surechantillionnage modulateur1
suite_diracs=kron(Symboles,[1, zeros(1,Ns-1)]);
%filtrage
X2=filter(h1,1, suite_diracs);
%filtre de reception
h2r=cat(2,ones(1,floor(Ns/2)),zeros(1, floor(Ns/2)));
%signal recue
X2r=filter(h2r,1,X2);
%diagrame de l'oeil
figure;
plot(reshape(X2r,Ns,length(X2r)/Ns));
title("diagrame de l'oeil de la premiere chaine");
%echantillionnage
n0=Ns;
X2e=X2r(n0:Ns:length(X2r));
%decisions/demapping
X2e(X2e>0)=1;
X2e(X2e<0)=0;
%TEB
erreur2= mean(abs(X2e - bits))

% bruit %%
Px=mean(abs(X2).^2);
figure;
for i=-1:3
    rapportEN=10^i;
    sigma=sqrt(Px*Ns/(2*log(M)*rapportEN));
    bruit=sigma*rand(1,length(X2));
    %signal bruit
    X2b=X2+bruit;
    %signal recu
    X2br=filter(h2r,1,X2b);
    subplot(2,3,(i+2));
    %diagrame de l'oeil
    plot(reshape(X2br,Ns,length(X2br)/Ns));
    str=sprintf('%f',rapportEN);
    title("diagrame de l'oeil pour E/N ="+ str);
end
sgtitle('question 2.3.1: Diagrame de l oeil de la 1ere chaine');
rapportEN=linspace(1,4,100)';
sigma=sqrt(Px*Ns./(2*log2(M).*rapportEN));
bruit=sigma*randn(1,length(X2));
X2t=repmat(X2,length(rapportEN),1);
X2b=X2t+bruit;
X2br=zeros(size(X2b));
for i=1:size(X1b,1)
    X2br(i,:)=filter(h2r,1,X2b(i,:));
end  
n0=Ns;
X2be=X2br(:,n0:Ns:length(X2br));
%decisions/demapping
X2be(X2be>0)=1;
X2be(X2be<0)=0;
%tracé du TEB
bitst=repmat(bits,length(rapportEN),1);
erreur2b= mean(abs(X2be - bitst),2)';
erreurth=qfunc(sqrt(rapportEN));
figure;
semilogy(10*log10(rapportEN),erreur2b);
hold on;
semilogy(10*log10(rapportEN),erreurth);
legend('TEB simulé','TEB theorique');
title('trace du TEB de la premiere chaine en fonction de Eb/No');
%% 4 %%
%information binaire a transmettre
    Fe=24000;
    Te=1/Fe;
    Rb=6000;
    %longueur du message en bits
    nb_bits=10000;
    %generation de l'information binaire a transmettre
    bits=randi([0 1],1,nb_bits);
    %nombre de symbole possibles pour le modulateur1 
    M=4;
    %debit symbole
    Rs=Rb/log2(M);
    %Duree symbole en nombre d'echantillons (Ts=NsTe)
    Ns=Fe/Rs;
    h4=ones(1,Ns);
    %Mapping binaire a? moyenne nulle : 00->-3, 01->-1, 11->1, 10->3
    Symboles=(2*bi2de(reshape(bits,2,length(bits)/2)')-3)';
    %Surechantillionnage modulateur1
    suite_diracs=kron(Symboles,[1 , zeros(1,Ns-1)]);
    X4=filter(h4,1, suite_diracs);
    X4r=filter(h4,1,X4);
    %diagramme de l'oeil
    figure;
    plot(reshape(X4r,Ns,[]));
    n0=Ns;
    X4e=X4r(n0:Ns:length(X4r))/Ns;
    title('Diagrame de l oeil de la 2eme chaine (sans canal)');
    %demapping
    X4edemap=reshape(de2bi((X4e+3)/2)',1,length(bits));
    %decisions 
    X4edemap(X4edemap>0)=1;
    X4edemap(X4edemap<0)=0;
    erreur3= mean(abs(X4edemap - bits))
    
%bruit
Px=mean(abs(X4).^2);
rapportEN=linspace(1,4,100)';
sigma=sqrt(Px*Ns./(2*log2(M).*rapportEN));
bruit=sigma*randn(1,length(X1));
X4t=repmat(X4,length(rapportEN),1);
X4b=X4t+bruit;
X4br=zeros(size(X4b));
for i=1:size(X4b,1)
    X4br(i,:)=filter(h4,1,X4b(i,:));
end  
n0=Ns;
X4be=X4br(:,n0:Ns:length(X4br))/Ns;

Symbolest=repmat(Symboles,length(rapportEN),1);
X4be(2<X4be)=3;
X4be(0<X4be & X4be<=2)=1;
X4be(0>=X4be & X4be>-2)=-1;
X4be(-2>=X4be)=-3;

X4edemap=zeros(length(rapportEN),length(bits));
for i=1:length(rapportEN)
    
X4edemap(i,:)=reshape(de2bi((X4be(i,:)+3)/2)',1,length(bits))';
end
endbitst=repmat(bits,length(rapportEN),1);
erreur4b= mean(X4be~=Symbolest,2)';
erreurth=3/2*qfunc(sqrt(4/5*rapportEN));
erreurth2=3/4*qfunc(sqrt(4/5*rapportEN));
figure;
semilogy(10*log10(rapportEN),erreur4b);
hold on;
semilogy(10*log10(rapportEN),erreurth);
title('tracé du TES de la 2ème chaine en fonction de Eb/No');
legend('TES simulé','TES théorique');
erreur4bb=mean(abs(X4edemap-endbitst),2)';
figure; 
semilogy(10*log10(rapportEN),erreur4bb);
hold on;
semilogy(10*log10(rapportEN),erreurth2);
title('tracé du TEB de la 2ème chaine en fonction de Eb/No');
legend('TEB simulé','TEB théorique');